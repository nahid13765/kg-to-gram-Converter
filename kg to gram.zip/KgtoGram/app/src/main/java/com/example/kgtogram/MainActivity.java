package com.example.kgtogram;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText edittextview;
    private Button buttonview;
    private TextView textresultview;
    private ImageView imageviewkg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edittextview =(EditText) findViewById(R.id.editTextNumberDecimal);
        buttonview = (Button) findViewById(R.id.button2);
        textresultview = (TextView) findViewById(R.id.textView2);
        imageviewkg = (ImageView) findViewById(R.id.imageButton6);
        buttonview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String s = edittextview.getText().toString();
                    double a = Double.parseDouble(s);
                    double gram = a * 1000.00;
                    textresultview.setText("     "+s+" kg = "+gram+" gram");
                }catch (Exception e){
                    Toast.makeText(MainActivity.this, "please enter a kg value", Toast.LENGTH_SHORT).show();
                }

            }
        });
        imageviewkg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this, "This is kg png image", Toast.LENGTH_SHORT).show();
            }
        });

    }
}